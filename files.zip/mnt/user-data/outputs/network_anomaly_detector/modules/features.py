"""
Feature Extraction Module
Converts network flows into feature vectors for machine learning
"""

import numpy as np
from typing import Dict, List
from sklearn.preprocessing import StandardScaler
import config
from logger import logger

class FeatureExtractor:
    """
    Extracts and normalizes features from network flows for ML models
    """
    
    # Feature names for reference
    FEATURE_NAMES = [
        'duration',              # 0: Flow duration in seconds
        'packet_count',          # 1: Total packets in flow
        'byte_count',            # 2: Total bytes in flow
        'packets_per_second',    # 3: Packet rate
        'bytes_per_second',      # 4: Byte rate
        'avg_packet_size',       # 5: Average packet size
        'min_packet_size',       # 6: Minimum packet size
        'max_packet_size',       # 7: Maximum packet size
        'fwd_packets_ratio',     # 8: Ratio of forward packets
        'fwd_bytes_ratio',       # 9: Ratio of forward bytes
        'avg_iat',               # 10: Average inter-arrival time
        'syn_count',             # 11: Number of SYN flags (TCP)
        'fin_count',             # 12: Number of FIN flags (TCP)
        'rst_count',             # 13: Number of RST flags (TCP)
        'protocol_encoded',      # 14: Protocol (normalized)
    ]
    
    def __init__(self):
        """Initialize feature extractor"""
        self.scaler = StandardScaler()
        self.is_fitted = False
        self.normalization_enabled = config.FEATURE_CONFIG['normalization']
        
        logger.log_system_event("FeatureExtractor initialized", 
                               f"Normalization: {self.normalization_enabled}")
    
    def extract_features(self, flow: Dict) -> np.ndarray:
        """
        Extract feature vector from a single flow
        
        Args:
            flow: Flow dictionary from Flow.to_dict()
            
        Returns:
            Feature vector as numpy array
        """
        # Extract raw features
        features = [
            flow.get('duration', 0),
            flow.get('packet_count', 0),
            flow.get('byte_count', 0),
            flow.get('packets_per_second', 0),
            flow.get('bytes_per_second', 0),
            flow.get('avg_packet_size', 0),
            flow.get('min_packet_size', 0),
            flow.get('max_packet_size', 0),
            self._calculate_ratio(flow.get('fwd_packets', 0), flow.get('packet_count', 1)),
            self._calculate_ratio(flow.get('fwd_bytes', 0), flow.get('byte_count', 1)),
            flow.get('avg_iat', 0),
            flow.get('syn_count', 0),
            flow.get('fin_count', 0),
            flow.get('rst_count', 0),
            self._encode_protocol(flow.get('protocol', 0)),
        ]
        
        return np.array(features, dtype=np.float64)
    
    def extract_features_batch(self, flows: List[Dict]) -> np.ndarray:
        """
        Extract features from multiple flows
        
        Args:
            flows: List of flow dictionaries
            
        Returns:
            2D numpy array of feature vectors
        """
        if not flows:
            return np.array([])
        
        feature_matrix = np.array([self.extract_features(flow) for flow in flows])
        return feature_matrix
    
    def fit_scaler(self, flows: List[Dict]):
        """
        Fit the normalization scaler on training data
        
        Args:
            flows: List of flow dictionaries for training
        """
        if not self.normalization_enabled:
            logger.info("Normalization disabled, skipping scaler fitting")
            return
        
        feature_matrix = self.extract_features_batch(flows)
        
        if feature_matrix.size == 0:
            logger.warning("No features to fit scaler")
            return
        
        self.scaler.fit(feature_matrix)
        self.is_fitted = True
        
        logger.info(f"Scaler fitted on {len(flows)} flows")
        logger.debug(f"Feature means: {self.scaler.mean_}")
        logger.debug(f"Feature stds: {np.sqrt(self.scaler.var_)}")
    
    def normalize_features(self, features: np.ndarray) -> np.ndarray:
        """
        Normalize feature vector(s) using fitted scaler
        
        Args:
            features: Feature vector or matrix
            
        Returns:
            Normalized features
        """
        if not self.normalization_enabled:
            return features
        
        if not self.is_fitted:
            logger.warning("Scaler not fitted, returning unnormalized features")
            return features
        
        # Handle both single vectors and matrices
        if features.ndim == 1:
            features = features.reshape(1, -1)
            normalized = self.scaler.transform(features)
            return normalized.flatten()
        else:
            return self.scaler.transform(features)
    
    def extract_and_normalize(self, flow: Dict) -> np.ndarray:
        """
        Extract and normalize features in one step
        
        Args:
            flow: Flow dictionary
            
        Returns:
            Normalized feature vector
        """
        features = self.extract_features(flow)
        return self.normalize_features(features)
    
    def extract_and_normalize_batch(self, flows: List[Dict]) -> np.ndarray:
        """
        Extract and normalize features for multiple flows
        
        Args:
            flows: List of flow dictionaries
            
        Returns:
            Normalized feature matrix
        """
        features = self.extract_features_batch(flows)
        return self.normalize_features(features)
    
    @staticmethod
    def _calculate_ratio(numerator: float, denominator: float) -> float:
        """
        Safely calculate ratio
        
        Args:
            numerator: Numerator value
            denominator: Denominator value
            
        Returns:
            Ratio or 0 if denominator is 0
        """
        return numerator / denominator if denominator > 0 else 0
    
    @staticmethod
    def _encode_protocol(protocol: int) -> float:
        """
        Encode protocol number
        
        Args:
            protocol: IP protocol number
            
        Returns:
            Encoded protocol value
        """
        # Simple encoding: normalize protocol numbers
        # Common protocols: TCP=6, UDP=17, ICMP=1
        protocol_map = {
            1: 0.1,   # ICMP
            6: 0.6,   # TCP
            17: 1.0,  # UDP
        }
        return protocol_map.get(protocol, protocol / 255.0)
    
    def get_feature_names(self) -> List[str]:
        """
        Get list of feature names
        
        Returns:
            List of feature names
        """
        return self.FEATURE_NAMES.copy()
    
    def get_feature_importance_dict(self, importance_scores: np.ndarray) -> Dict[str, float]:
        """
        Create dictionary mapping feature names to importance scores
        
        Args:
            importance_scores: Array of importance scores
            
        Returns:
            Dictionary of feature: importance
        """
        if len(importance_scores) != len(self.FEATURE_NAMES):
            logger.error("Importance scores length doesn't match feature count")
            return {}
        
        return dict(zip(self.FEATURE_NAMES, importance_scores))
    
    def validate_features(self, features: np.ndarray) -> bool:
        """
        Validate feature vector
        
        Args:
            features: Feature vector to validate
            
        Returns:
            True if valid
        """
        # Check for NaN or Inf values
        if np.any(np.isnan(features)) or np.any(np.isinf(features)):
            logger.warning("Features contain NaN or Inf values")
            return False
        
        # Check feature count
        expected_count = len(self.FEATURE_NAMES)
        if features.shape[-1] != expected_count:
            logger.warning(f"Feature count mismatch: expected {expected_count}, "
                         f"got {features.shape[-1]}")
            return False
        
        return True
    
    def get_statistics(self) -> Dict:
        """
        Get feature extractor statistics
        
        Returns:
            Statistics dictionary
        """
        return {
            'feature_count': len(self.FEATURE_NAMES),
            'normalization_enabled': self.normalization_enabled,
            'scaler_fitted': self.is_fitted,
            'feature_names': self.FEATURE_NAMES,
        }

if __name__ == "__main__":
    # Test feature extraction
    print("Feature Extraction Test")
    print("=" * 50)
    
    extractor = FeatureExtractor()
    
    # Create sample flow
    sample_flow = {
        'duration': 10.5,
        'packet_count': 100,
        'byte_count': 50000,
        'packets_per_second': 9.52,
        'bytes_per_second': 4761.9,
        'avg_packet_size': 500,
        'min_packet_size': 40,
        'max_packet_size': 1500,
        'fwd_packets': 60,
        'fwd_bytes': 30000,
        'bwd_packets': 40,
        'bwd_bytes': 20000,
        'avg_iat': 0.105,
        'syn_count': 1,
        'fin_count': 1,
        'rst_count': 0,
        'protocol': 6,
    }
    
    # Extract features
    features = extractor.extract_features(sample_flow)
    print(f"\nExtracted {len(features)} features:")
    for name, value in zip(extractor.FEATURE_NAMES, features):
        print(f"  {name:25s}: {value:.4f}")
    
    # Test batch extraction
    flows = [sample_flow] * 5
    feature_matrix = extractor.extract_features_batch(flows)
    print(f"\nBatch extraction: {feature_matrix.shape}")
    
    # Test normalization
    extractor.fit_scaler(flows)
    normalized = extractor.normalize_features(features)
    print(f"\nNormalized features: {normalized}")
    
    # Validate
    is_valid = extractor.validate_features(features)
    print(f"\nFeature validation: {is_valid}")
    
    # Statistics
    stats = extractor.get_statistics()
    print(f"\nStatistics: {stats}")
