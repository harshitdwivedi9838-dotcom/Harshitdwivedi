"""
Packet Capture Module
Captures network packets using Scapy with support for live and PCAP file modes
"""

import time
from datetime import datetime
from threading import Thread, Event
from queue import Queue
import sys

try:
    from scapy.all import sniff, rdpcap, IP, TCP, UDP, ICMP, wrpcap
    from scapy.layers.inet import Ether
except ImportError:
    print("ERROR: Scapy not installed. Install with: pip install scapy")
    sys.exit(1)

import config
from logger import logger

class PacketCapture:
    """
    Network packet capture system supporting live capture and PCAP replay
    """
    
    def __init__(self, interface=None, pcap_file=None, packet_queue=None):
        """
        Initialize packet capture
        
        Args:
            interface: Network interface to capture from (e.g., 'eth0', 'wlan0')
            pcap_file: Path to PCAP file for offline analysis
            packet_queue: Queue to send captured packets to
        """
        self.interface = interface or config.CAPTURE_CONFIG['interface']
        self.pcap_file = pcap_file
        self.packet_queue = packet_queue or Queue(maxsize=config.CAPTURE_CONFIG['capture_buffer_size'])
        
        self.is_running = False
        self.stop_event = Event()
        self.capture_thread = None
        
        self.total_packets = 0
        self.packets_tcp = 0
        self.packets_udp = 0
        self.packets_icmp = 0
        self.packets_other = 0
        
        self.start_time = None
        
        logger.log_system_event("PacketCapture initialized", 
                               f"Interface: {self.interface}, PCAP: {self.pcap_file}")
    
    def start_capture(self, count=0, prn=None):
        """
        Start packet capture in a separate thread
        
        Args:
            count: Number of packets to capture (0 = infinite)
            prn: Callback function for each packet
        """
        if self.is_running:
            logger.warning("Packet capture already running")
            return
        
        self.is_running = True
        self.stop_event.clear()
        self.start_time = time.time()
        
        if self.pcap_file:
            # Offline mode: read from PCAP file
            self.capture_thread = Thread(target=self._capture_from_pcap, args=(prn,))
            logger.info(f"Starting offline capture from {self.pcap_file}")
        else:
            # Live mode: capture from network interface
            self.capture_thread = Thread(target=self._capture_live, args=(count, prn))
            logger.info(f"Starting live capture on interface {self.interface}")
        
        self.capture_thread.daemon = True
        self.capture_thread.start()
    
    def _capture_live(self, count, prn):
        """
        Capture packets from network interface
        
        Args:
            count: Number of packets to capture
            prn: Packet processing callback
        """
        try:
            # Build packet filter if specified
            bpf_filter = config.CAPTURE_CONFIG.get('bpf_filter', '')
            
            # Start sniffing
            sniff(
                iface=self.interface,
                prn=lambda pkt: self._process_packet(pkt, prn),
                count=count,
                store=False,  # Don't store packets in memory
                filter=bpf_filter if bpf_filter else None,
                stop_filter=lambda _: self.stop_event.is_set()
            )
        except PermissionError:
            logger.error("Permission denied. Run with sudo/administrator privileges")
            self.is_running = False
        except Exception as e:
            logger.error(f"Capture error: {str(e)}")
            self.is_running = False
    
    def _capture_from_pcap(self, prn):
        """
        Replay packets from PCAP file
        
        Args:
            prn: Packet processing callback
        """
        try:
            packets = rdpcap(str(self.pcap_file))
            logger.info(f"Loaded {len(packets)} packets from {self.pcap_file}")
            
            replay_speed = config.DEMO_CONFIG.get('replay_speed', 1.0)
            last_timestamp = None
            
            for packet in packets:
                if self.stop_event.is_set():
                    break
                
                # Simulate timing between packets
                if last_timestamp and hasattr(packet, 'time'):
                    delay = (packet.time - last_timestamp) / replay_speed
                    if delay > 0:
                        time.sleep(min(delay, 1.0))  # Cap delay at 1 second
                
                self._process_packet(packet, prn)
                
                if hasattr(packet, 'time'):
                    last_timestamp = packet.time
            
            logger.info("PCAP replay completed")
            self.is_running = False
            
        except FileNotFoundError:
            logger.error(f"PCAP file not found: {self.pcap_file}")
            self.is_running = False
        except Exception as e:
            logger.error(f"PCAP read error: {str(e)}")
            self.is_running = False
    
    def _process_packet(self, packet, callback):
        """
        Process captured packet and extract relevant information
        
        Args:
            packet: Scapy packet object
            callback: Optional callback function
        """
        try:
            # Only process IP packets
            if not packet.haslayer(IP):
                return
            
            ip_layer = packet[IP]
            
            # Extract packet information
            packet_info = {
                'timestamp': time.time(),
                'src_ip': ip_layer.src,
                'dst_ip': ip_layer.dst,
                'protocol': ip_layer.proto,
                'length': len(packet),
                'ttl': ip_layer.ttl,
            }
            
            # Extract layer 4 information (TCP/UDP)
            if packet.haslayer(TCP):
                tcp_layer = packet[TCP]
                packet_info['src_port'] = tcp_layer.sport
                packet_info['dst_port'] = tcp_layer.dport
                packet_info['flags'] = tcp_layer.flags
                packet_info['seq'] = tcp_layer.seq
                packet_info['ack'] = tcp_layer.ack
                self.packets_tcp += 1
                
            elif packet.haslayer(UDP):
                udp_layer = packet[UDP]
                packet_info['src_port'] = udp_layer.sport
                packet_info['dst_port'] = udp_layer.dport
                self.packets_udp += 1
                
            elif packet.haslayer(ICMP):
                icmp_layer = packet[ICMP]
                packet_info['icmp_type'] = icmp_layer.type
                packet_info['icmp_code'] = icmp_layer.code
                packet_info['src_port'] = None
                packet_info['dst_port'] = None
                self.packets_icmp += 1
            else:
                packet_info['src_port'] = None
                packet_info['dst_port'] = None
                self.packets_other += 1
            
            # Update counters
            self.total_packets += 1
            
            # Add to queue
            if not self.packet_queue.full():
                self.packet_queue.put(packet_info)
            
            # Call custom callback if provided
            if callback:
                callback(packet_info)
            
            # Periodic logging
            if self.total_packets % 100 == 0:
                logger.debug(f"Captured {self.total_packets} packets "
                           f"(TCP:{self.packets_tcp}, UDP:{self.packets_udp}, "
                           f"ICMP:{self.packets_icmp}, Other:{self.packets_other})")
        
        except Exception as e:
            logger.error(f"Packet processing error: {str(e)}")
    
    def stop_capture(self):
        """Stop packet capture"""
        if not self.is_running:
            return
        
        logger.info("Stopping packet capture...")
        self.stop_event.set()
        self.is_running = False
        
        if self.capture_thread:
            self.capture_thread.join(timeout=5)
        
        # Log statistics
        duration = time.time() - self.start_time if self.start_time else 0
        logger.log_system_event(
            "Capture stopped",
            f"Total: {self.total_packets} packets in {duration:.1f}s "
            f"({self.total_packets/duration:.1f} pps)" if duration > 0 else ""
        )
    
    def get_packet(self, timeout=1):
        """
        Get next packet from queue
        
        Args:
            timeout: Timeout in seconds
            
        Returns:
            Packet info dict or None
        """
        try:
            return self.packet_queue.get(timeout=timeout)
        except:
            return None
    
    def get_statistics(self):
        """
        Get capture statistics
        
        Returns:
            Dictionary with capture stats
        """
        duration = time.time() - self.start_time if self.start_time else 0
        
        return {
            'total_packets': self.total_packets,
            'tcp_packets': self.packets_tcp,
            'udp_packets': self.packets_udp,
            'icmp_packets': self.packets_icmp,
            'other_packets': self.packets_other,
            'duration': duration,
            'packets_per_second': self.total_packets / duration if duration > 0 else 0,
            'is_running': self.is_running,
            'queue_size': self.packet_queue.qsize(),
        }
    
    @staticmethod
    def get_available_interfaces():
        """
        Get list of available network interfaces
        
        Returns:
            List of interface names
        """
        try:
            from scapy.all import get_if_list
            return get_if_list()
        except Exception as e:
            logger.error(f"Could not get interface list: {str(e)}")
            return []
    
    @staticmethod
    def save_to_pcap(packets, filename):
        """
        Save packets to PCAP file
        
        Args:
            packets: List of Scapy packets
            filename: Output PCAP filename
        """
        try:
            wrpcap(filename, packets)
            logger.info(f"Saved {len(packets)} packets to {filename}")
        except Exception as e:
            logger.error(f"Could not save PCAP: {str(e)}")

def packet_callback_example(packet_info):
    """Example callback function for packet processing"""
    print(f"[{packet_info['timestamp']:.2f}] "
          f"{packet_info['src_ip']}:{packet_info.get('src_port', 'N/A')} -> "
          f"{packet_info['dst_ip']}:{packet_info.get('dst_port', 'N/A')} "
          f"[Proto: {packet_info['protocol']}, Len: {packet_info['length']}]")

if __name__ == "__main__":
    # Test packet capture
    print("Network Packet Capture Test")
    print("=" * 50)
    
    # List available interfaces
    interfaces = PacketCapture.get_available_interfaces()
    print(f"Available interfaces: {interfaces}")
    
    # Create capture instance
    # NOTE: For live capture, you need root/admin privileges
    # For testing without privileges, use a PCAP file
    
    capture = PacketCapture()
    
    # Start capture (will capture 50 packets for testing)
    print("\nStarting packet capture (50 packets)...")
    capture.start_capture(count=50, prn=packet_callback_example)
    
    # Wait for capture to complete
    time.sleep(10)
    
    # Get statistics
    stats = capture.get_statistics()
    print("\nCapture Statistics:")
    for key, value in stats.items():
        print(f"  {key}: {value}")
    
    # Stop capture
    capture.stop_capture()
