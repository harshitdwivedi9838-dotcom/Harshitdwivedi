"""
Flow Builder Module
Aggregates packets into bidirectional network flows
"""

import time
from collections import defaultdict
from threading import Lock
from typing import Dict, Tuple, Optional
import config
from logger import logger

class Flow:
    """
    Represents a bidirectional network flow
    """
    
    def __init__(self, flow_key: str, src_ip: str, dst_ip: str, 
                 src_port: Optional[int], dst_port: Optional[int], protocol: int):
        """
        Initialize a network flow
        
        Args:
            flow_key: Unique flow identifier
            src_ip: Source IP address
            dst_ip: Destination IP address
            src_port: Source port (None for ICMP)
            dst_port: Destination port (None for ICMP)
            protocol: IP protocol number (6=TCP, 17=UDP, 1=ICMP)
        """
        self.flow_key = flow_key
        self.src_ip = src_ip
        self.dst_ip = dst_ip
        self.src_port = src_port
        self.dst_port = dst_port
        self.protocol = protocol
        
        # Flow statistics
        self.packet_count = 0
        self.byte_count = 0
        self.start_time = time.time()
        self.last_packet_time = self.start_time
        self.end_time = None
        
        # Forward and backward counters
        self.fwd_packets = 0
        self.fwd_bytes = 0
        self.bwd_packets = 0
        self.bwd_bytes = 0
        
        # TCP-specific
        self.syn_count = 0
        self.fin_count = 0
        self.rst_count = 0
        self.psh_count = 0
        self.ack_count = 0
        
        # Packet size statistics
        self.min_packet_size = float('inf')
        self.max_packet_size = 0
        self.packet_sizes = []
        
        # Inter-arrival times
        self.inter_arrival_times = []
        self.last_packet_timestamp = None
    
    def add_packet(self, packet_info: Dict, is_forward: bool = True):
        """
        Add a packet to this flow
        
        Args:
            packet_info: Dictionary containing packet information
            is_forward: True if packet is in forward direction
        """
        self.packet_count += 1
        packet_length = packet_info['length']
        self.byte_count += packet_length
        
        # Update directional counters
        if is_forward:
            self.fwd_packets += 1
            self.fwd_bytes += packet_length
        else:
            self.bwd_packets += 1
            self.bwd_bytes += packet_length
        
        # Update packet size statistics
        self.min_packet_size = min(self.min_packet_size, packet_length)
        self.max_packet_size = max(self.max_packet_size, packet_length)
        self.packet_sizes.append(packet_length)
        
        # Calculate inter-arrival time
        current_time = packet_info['timestamp']
        if self.last_packet_timestamp:
            iat = current_time - self.last_packet_timestamp
            self.inter_arrival_times.append(iat)
        self.last_packet_timestamp = current_time
        
        # Update timing
        self.last_packet_time = current_time
        
        # TCP flags
        if self.protocol == 6 and 'flags' in packet_info:
            flags = packet_info['flags']
            if flags & 0x02:  # SYN
                self.syn_count += 1
            if flags & 0x01:  # FIN
                self.fin_count += 1
            if flags & 0x04:  # RST
                self.rst_count += 1
            if flags & 0x08:  # PSH
                self.psh_count += 1
            if flags & 0x10:  # ACK
                self.ack_count += 1
    
    def get_duration(self) -> float:
        """Get flow duration in seconds"""
        if self.end_time:
            return self.end_time - self.start_time
        return self.last_packet_time - self.start_time
    
    def get_avg_packet_size(self) -> float:
        """Get average packet size"""
        return self.byte_count / self.packet_count if self.packet_count > 0 else 0
    
    def get_packets_per_second(self) -> float:
        """Get packets per second rate"""
        duration = self.get_duration()
        return self.packet_count / duration if duration > 0 else 0
    
    def get_bytes_per_second(self) -> float:
        """Get bytes per second rate"""
        duration = self.get_duration()
        return self.byte_count / duration if duration > 0 else 0
    
    def get_avg_inter_arrival_time(self) -> float:
        """Get average inter-arrival time between packets"""
        if not self.inter_arrival_times:
            return 0
        return sum(self.inter_arrival_times) / len(self.inter_arrival_times)
    
    def is_expired(self, timeout: int) -> bool:
        """
        Check if flow has expired (no packets for timeout seconds)
        
        Args:
            timeout: Timeout in seconds
            
        Returns:
            True if expired
        """
        return (time.time() - self.last_packet_time) > timeout
    
    def finalize(self):
        """Mark flow as complete"""
        self.end_time = self.last_packet_time
    
    def to_dict(self) -> Dict:
        """
        Convert flow to dictionary for storage/analysis
        
        Returns:
            Dictionary representation of flow
        """
        return {
            'flow_key': self.flow_key,
            'src_ip': self.src_ip,
            'dst_ip': self.dst_ip,
            'src_port': self.src_port,
            'dst_port': self.dst_port,
            'protocol': self.protocol,
            'packet_count': self.packet_count,
            'byte_count': self.byte_count,
            'start_time': self.start_time,
            'end_time': self.end_time,
            'duration': self.get_duration(),
            'avg_packet_size': self.get_avg_packet_size(),
            'packets_per_second': self.get_packets_per_second(),
            'bytes_per_second': self.get_bytes_per_second(),
            'fwd_packets': self.fwd_packets,
            'fwd_bytes': self.fwd_bytes,
            'bwd_packets': self.bwd_packets,
            'bwd_bytes': self.bwd_bytes,
            'min_packet_size': self.min_packet_size if self.min_packet_size != float('inf') else 0,
            'max_packet_size': self.max_packet_size,
            'avg_iat': self.get_avg_inter_arrival_time(),
            'syn_count': self.syn_count,
            'fin_count': self.fin_count,
            'rst_count': self.rst_count,
            'psh_count': self.psh_count,
            'ack_count': self.ack_count,
        }


class FlowBuilder:
    """
    Builds and manages network flows from packet stream
    """
    
    def __init__(self):
        """Initialize flow builder"""
        self.active_flows = {}  # flow_key -> Flow
        self.flow_lock = Lock()
        self.flow_timeout = config.FLOW_CONFIG['flow_timeout']
        self.max_active_flows = config.FLOW_CONFIG['max_active_flows']
        
        self.total_flows_created = 0
        self.total_flows_expired = 0
        
        logger.log_system_event("FlowBuilder initialized", 
                               f"Timeout: {self.flow_timeout}s")
    
    @staticmethod
    def create_flow_key(src_ip: str, dst_ip: str, src_port: Optional[int], 
                        dst_port: Optional[int], protocol: int) -> Tuple[str, bool]:
        """
        Create bidirectional flow key
        
        Args:
            src_ip: Source IP
            dst_ip: Destination IP
            src_port: Source port
            dst_port: Destination port
            protocol: Protocol number
            
        Returns:
            Tuple of (flow_key, is_forward)
        """
        # Create sorted endpoints for bidirectional matching
        # Format: ip1:port1<->ip2:port2:protocol
        
        if src_port is None or dst_port is None:
            # For ICMP and protocols without ports
            endpoint1 = f"{src_ip}"
            endpoint2 = f"{dst_ip}"
        else:
            endpoint1 = f"{src_ip}:{src_port}"
            endpoint2 = f"{dst_ip}:{dst_port}"
        
        # Sort endpoints to create bidirectional key
        if endpoint1 < endpoint2:
            flow_key = f"{endpoint1}<->{endpoint2}:{protocol}"
            is_forward = True
        else:
            flow_key = f"{endpoint2}<->{endpoint1}:{protocol}"
            is_forward = False
        
        return flow_key, is_forward
    
    def process_packet(self, packet_info: Dict) -> Optional[Flow]:
        """
        Process packet and add to appropriate flow
        
        Args:
            packet_info: Packet information dictionary
            
        Returns:
            Flow object or None
        """
        # Create flow key
        flow_key, is_forward = self.create_flow_key(
            packet_info['src_ip'],
            packet_info['dst_ip'],
            packet_info.get('src_port'),
            packet_info.get('dst_port'),
            packet_info['protocol']
        )
        
        with self.flow_lock:
            # Get or create flow
            if flow_key not in self.active_flows:
                # Check if we've hit max flows
                if len(self.active_flows) >= self.max_active_flows:
                    logger.warning(f"Max active flows ({self.max_active_flows}) reached. "
                                 "Cleaning up old flows...")
                    self.cleanup_expired_flows()
                
                # Create new flow
                flow = Flow(
                    flow_key,
                    packet_info['src_ip'],
                    packet_info['dst_ip'],
                    packet_info.get('src_port'),
                    packet_info.get('dst_port'),
                    packet_info['protocol']
                )
                self.active_flows[flow_key] = flow
                self.total_flows_created += 1
                logger.log_flow_created(flow_key)
            else:
                flow = self.active_flows[flow_key]
            
            # Add packet to flow
            flow.add_packet(packet_info, is_forward)
            
            return flow
    
    def get_flow(self, flow_key: str) -> Optional[Flow]:
        """Get flow by key"""
        with self.flow_lock:
            return self.active_flows.get(flow_key)
    
    def get_all_flows(self) -> Dict[str, Flow]:
        """Get all active flows"""
        with self.flow_lock:
            return dict(self.active_flows)
    
    def cleanup_expired_flows(self) -> list:
        """
        Remove expired flows
        
        Returns:
            List of expired flows
        """
        expired_flows = []
        
        with self.flow_lock:
            current_time = time.time()
            flows_to_remove = []
            
            for flow_key, flow in self.active_flows.items():
                if flow.is_expired(self.flow_timeout):
                    flow.finalize()
                    expired_flows.append(flow)
                    flows_to_remove.append(flow_key)
                    logger.log_flow_expired(flow_key, flow.get_duration())
            
            # Remove expired flows
            for flow_key in flows_to_remove:
                del self.active_flows[flow_key]
                self.total_flows_expired += 1
        
        if expired_flows:
            logger.info(f"Cleaned up {len(expired_flows)} expired flows")
        
        return expired_flows
    
    def finalize_all_flows(self) -> list:
        """
        Finalize all active flows
        
        Returns:
            List of all flows
        """
        with self.flow_lock:
            all_flows = []
            for flow in self.active_flows.values():
                flow.finalize()
                all_flows.append(flow)
            
            self.active_flows.clear()
            logger.info(f"Finalized {len(all_flows)} flows")
            
            return all_flows
    
    def get_statistics(self) -> Dict:
        """
        Get flow builder statistics
        
        Returns:
            Statistics dictionary
        """
        with self.flow_lock:
            return {
                'active_flows': len(self.active_flows),
                'total_flows_created': self.total_flows_created,
                'total_flows_expired': self.total_flows_expired,
                'flow_timeout': self.flow_timeout,
                'max_active_flows': self.max_active_flows,
            }

if __name__ == "__main__":
    # Test flow builder
    print("Flow Builder Test")
    print("=" * 50)
    
    builder = FlowBuilder()
    
    # Simulate packets
    test_packets = [
        {'src_ip': '192.168.1.1', 'dst_ip': '10.0.0.1', 'src_port': 12345, 
         'dst_port': 80, 'protocol': 6, 'length': 100, 'timestamp': time.time(), 'flags': 0x02},
        {'src_ip': '10.0.0.1', 'dst_ip': '192.168.1.1', 'src_port': 80, 
         'dst_port': 12345, 'protocol': 6, 'length': 150, 'timestamp': time.time(), 'flags': 0x12},
        {'src_ip': '192.168.1.1', 'dst_ip': '10.0.0.1', 'src_port': 12345, 
         'dst_port': 80, 'protocol': 6, 'length': 200, 'timestamp': time.time(), 'flags': 0x10},
    ]
    
    # Process packets
    for packet in test_packets:
        flow = builder.process_packet(packet)
        print(f"Processed packet -> Flow: {flow.flow_key}")
    
    # Get statistics
    stats = builder.get_statistics()
    print(f"\nFlow Statistics: {stats}")
    
    # Get flows
    flows = builder.get_all_flows()
    for flow_key, flow in flows.items():
        print(f"\nFlow: {flow_key}")
        print(f"  Packets: {flow.packet_count} ({flow.fwd_packets} fwd, {flow.bwd_packets} bwd)")
        print(f"  Bytes: {flow.byte_count}")
        print(f"  Duration: {flow.get_duration():.3f}s")
        print(f"  Avg packet size: {flow.get_avg_packet_size():.1f} bytes")
        print(f"  Rate: {flow.get_packets_per_second():.1f} pps")
