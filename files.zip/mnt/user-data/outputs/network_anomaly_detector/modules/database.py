"""
Database Module
SQLite-based persistence layer for network traffic data
"""

import sqlite3
from datetime import datetime
from pathlib import Path
import json
from typing import List, Dict, Optional
import config
from logger import logger

class DatabaseManager:
    """
    Manages all database operations for the network anomaly detector
    """
    
    def __init__(self, db_path=None):
        """
        Initialize database connection and create tables
        
        Args:
            db_path: Path to SQLite database file
        """
        self.db_path = db_path or config.DATABASE_PATH
        self.conn = None
        self.cursor = None
        self._connect()
        self._create_tables()
        logger.log_system_event("Database initialized", str(self.db_path))
    
    def _connect(self):
        """Establish database connection"""
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row  # Enable column access by name
        self.cursor = self.conn.cursor()
    
    def _create_tables(self):
        """Create database schema"""
        
        # Flows table - stores network flow information
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS flows (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                flow_key TEXT NOT NULL,
                src_ip TEXT NOT NULL,
                dst_ip TEXT NOT NULL,
                src_port INTEGER,
                dst_port INTEGER,
                protocol INTEGER NOT NULL,
                packet_count INTEGER DEFAULT 0,
                byte_count INTEGER DEFAULT 0,
                start_time REAL NOT NULL,
                end_time REAL,
                duration REAL,
                avg_packet_size REAL,
                packets_per_second REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Anomalies table - stores detected anomalies
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS anomalies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                flow_id INTEGER,
                flow_key TEXT NOT NULL,
                anomaly_score REAL NOT NULL,
                detection_method TEXT NOT NULL,
                reason TEXT,
                severity TEXT DEFAULT 'MEDIUM',
                src_ip TEXT NOT NULL,
                dst_ip TEXT NOT NULL,
                protocol INTEGER,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (flow_id) REFERENCES flows(id)
            )
        """)
        
        # Attacks table - stores rule-based attack detections
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS attacks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                attack_type TEXT NOT NULL,
                source_ip TEXT NOT NULL,
                target_ip TEXT,
                details TEXT,
                severity TEXT DEFAULT 'HIGH',
                packet_count INTEGER,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Statistics table - stores traffic statistics
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS statistics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                metric_name TEXT NOT NULL,
                metric_value REAL NOT NULL,
                category TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Traffic timeline - for visualization
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS traffic_timeline (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TIMESTAMP NOT NULL,
                packet_count INTEGER DEFAULT 0,
                byte_count INTEGER DEFAULT 0,
                flow_count INTEGER DEFAULT 0,
                anomaly_count INTEGER DEFAULT 0
            )
        """)
        
        # Create indexes for better query performance
        self.cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_flows_src_ip ON flows(src_ip)
        """)
        self.cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_flows_dst_ip ON flows(dst_ip)
        """)
        self.cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_anomalies_timestamp ON anomalies(timestamp)
        """)
        self.cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_attacks_timestamp ON attacks(timestamp)
        """)
        
        self.conn.commit()
        logger.log_database_operation("Schema created", "all tables")
    
    def insert_flow(self, flow_data: Dict) -> int:
        """
        Insert a new flow record
        
        Args:
            flow_data: Dictionary containing flow information
            
        Returns:
            Flow ID
        """
        query = """
            INSERT INTO flows (
                flow_key, src_ip, dst_ip, src_port, dst_port, protocol,
                packet_count, byte_count, start_time, end_time, duration,
                avg_packet_size, packets_per_second
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        self.cursor.execute(query, (
            flow_data['flow_key'],
            flow_data['src_ip'],
            flow_data['dst_ip'],
            flow_data.get('src_port'),
            flow_data.get('dst_port'),
            flow_data['protocol'],
            flow_data['packet_count'],
            flow_data['byte_count'],
            flow_data['start_time'],
            flow_data.get('end_time'),
            flow_data.get('duration'),
            flow_data.get('avg_packet_size'),
            flow_data.get('packets_per_second')
        ))
        
        self.conn.commit()
        flow_id = self.cursor.lastrowid
        logger.log_database_operation("INSERT", "flows", 1)
        return flow_id
    
    def insert_anomaly(self, anomaly_data: Dict) -> int:
        """
        Insert an anomaly detection record
        
        Args:
            anomaly_data: Dictionary containing anomaly information
            
        Returns:
            Anomaly ID
        """
        query = """
            INSERT INTO anomalies (
                flow_id, flow_key, anomaly_score, detection_method,
                reason, severity, src_ip, dst_ip, protocol
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        self.cursor.execute(query, (
            anomaly_data.get('flow_id'),
            anomaly_data['flow_key'],
            anomaly_data['anomaly_score'],
            anomaly_data['detection_method'],
            anomaly_data.get('reason'),
            anomaly_data.get('severity', 'MEDIUM'),
            anomaly_data['src_ip'],
            anomaly_data['dst_ip'],
            anomaly_data.get('protocol')
        ))
        
        self.conn.commit()
        anomaly_id = self.cursor.lastrowid
        logger.log_database_operation("INSERT", "anomalies", 1)
        return anomaly_id
    
    def insert_attack(self, attack_data: Dict) -> int:
        """
        Insert an attack detection record
        
        Args:
            attack_data: Dictionary containing attack information
            
        Returns:
            Attack ID
        """
        query = """
            INSERT INTO attacks (
                attack_type, source_ip, target_ip, details,
                severity, packet_count
            ) VALUES (?, ?, ?, ?, ?, ?)
        """
        
        self.cursor.execute(query, (
            attack_data['attack_type'],
            attack_data['source_ip'],
            attack_data.get('target_ip'),
            attack_data.get('details'),
            attack_data.get('severity', 'HIGH'),
            attack_data.get('packet_count')
        ))
        
        self.conn.commit()
        attack_id = self.cursor.lastrowid
        logger.log_database_operation("INSERT", "attacks", 1)
        return attack_id
    
    def insert_statistic(self, metric_name: str, value: float, category: str = None):
        """Insert a statistics record"""
        query = """
            INSERT INTO statistics (metric_name, metric_value, category)
            VALUES (?, ?, ?)
        """
        self.cursor.execute(query, (metric_name, value, category))
        self.conn.commit()
    
    def update_traffic_timeline(self, packet_count: int, byte_count: int,
                                flow_count: int, anomaly_count: int = 0):
        """Update traffic timeline for current minute"""
        query = """
            INSERT INTO traffic_timeline (timestamp, packet_count, byte_count, flow_count, anomaly_count)
            VALUES (datetime('now'), ?, ?, ?, ?)
        """
        self.cursor.execute(query, (packet_count, byte_count, flow_count, anomaly_count))
        self.conn.commit()
    
    def get_recent_flows(self, limit: int = 100) -> List[Dict]:
        """Get most recent flows"""
        query = """
            SELECT * FROM flows
            ORDER BY created_at DESC
            LIMIT ?
        """
        self.cursor.execute(query, (limit,))
        return [dict(row) for row in self.cursor.fetchall()]
    
    def get_recent_anomalies(self, limit: int = 50) -> List[Dict]:
        """Get most recent anomalies"""
        query = """
            SELECT * FROM anomalies
            ORDER BY timestamp DESC
            LIMIT ?
        """
        self.cursor.execute(query, (limit,))
        return [dict(row) for row in self.cursor.fetchall()]
    
    def get_recent_attacks(self, limit: int = 50) -> List[Dict]:
        """Get most recent attacks"""
        query = """
            SELECT * FROM attacks
            ORDER BY timestamp DESC
            LIMIT ?
        """
        self.cursor.execute(query, (limit,))
        return [dict(row) for row in self.cursor.fetchall()]
    
    def get_suspicious_ips(self, min_anomalies: int = 3) -> List[Dict]:
        """Get IPs with multiple anomalies"""
        query = """
            SELECT src_ip, COUNT(*) as anomaly_count,
                   MAX(timestamp) as last_seen,
                   AVG(anomaly_score) as avg_score
            FROM anomalies
            GROUP BY src_ip
            HAVING anomaly_count >= ?
            ORDER BY anomaly_count DESC
        """
        self.cursor.execute(query, (min_anomalies,))
        return [dict(row) for row in self.cursor.fetchall()]
    
    def get_traffic_timeline(self, minutes: int = 60) -> List[Dict]:
        """Get traffic timeline for last N minutes"""
        query = """
            SELECT * FROM traffic_timeline
            WHERE timestamp >= datetime('now', '-' || ? || ' minutes')
            ORDER BY timestamp ASC
        """
        self.cursor.execute(query, (minutes,))
        return [dict(row) for row in self.cursor.fetchall()]
    
    def get_protocol_distribution(self) -> List[Dict]:
        """Get distribution of protocols in recent traffic"""
        query = """
            SELECT protocol, COUNT(*) as count, SUM(packet_count) as total_packets
            FROM flows
            WHERE created_at >= datetime('now', '-1 hour')
            GROUP BY protocol
            ORDER BY count DESC
        """
        self.cursor.execute(query)
        return [dict(row) for row in self.cursor.fetchall()]
    
    def get_top_talkers(self, limit: int = 10) -> List[Dict]:
        """Get top traffic sources by packet count"""
        query = """
            SELECT src_ip, 
                   COUNT(*) as flow_count,
                   SUM(packet_count) as total_packets,
                   SUM(byte_count) as total_bytes
            FROM flows
            WHERE created_at >= datetime('now', '-1 hour')
            GROUP BY src_ip
            ORDER BY total_packets DESC
            LIMIT ?
        """
        self.cursor.execute(query, (limit,))
        return [dict(row) for row in self.cursor.fetchall()]
    
    def get_statistics_summary(self) -> Dict:
        """Get summary statistics"""
        total_flows = self.cursor.execute("SELECT COUNT(*) FROM flows").fetchone()[0]
        total_anomalies = self.cursor.execute("SELECT COUNT(*) FROM anomalies").fetchone()[0]
        total_attacks = self.cursor.execute("SELECT COUNT(*) FROM attacks").fetchone()[0]
        
        return {
            'total_flows': total_flows,
            'total_anomalies': total_anomalies,
            'total_attacks': total_attacks,
            'anomaly_rate': (total_anomalies / total_flows * 100) if total_flows > 0 else 0
        }
    
    def clear_old_data(self, days: int = 7):
        """Clear data older than specified days"""
        self.cursor.execute("DELETE FROM flows WHERE created_at < datetime('now', '-' || ? || ' days')", (days,))
        self.cursor.execute("DELETE FROM anomalies WHERE timestamp < datetime('now', '-' || ? || ' days')", (days,))
        self.cursor.execute("DELETE FROM attacks WHERE timestamp < datetime('now', '-' || ? || ' days')", (days,))
        self.cursor.execute("DELETE FROM traffic_timeline WHERE timestamp < datetime('now', '-' || ? || ' days')", (days,))
        self.conn.commit()
        logger.log_database_operation("CLEANUP", f"data older than {days} days")
    
    def close(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()
            logger.log_system_event("Database connection closed")

# Global database instance
db = DatabaseManager()

if __name__ == "__main__":
    # Test database operations
    print("Testing database operations...")
    
    # Test flow insertion
    test_flow = {
        'flow_key': '192.168.1.1:80->10.0.0.1:443',
        'src_ip': '192.168.1.1',
        'dst_ip': '10.0.0.1',
        'src_port': 80,
        'dst_port': 443,
        'protocol': 6,
        'packet_count': 100,
        'byte_count': 50000,
        'start_time': datetime.now().timestamp(),
        'duration': 10.5,
        'avg_packet_size': 500,
        'packets_per_second': 9.5
    }
    
    flow_id = db.insert_flow(test_flow)
    print(f"Inserted flow with ID: {flow_id}")
    
    # Get summary
    summary = db.get_statistics_summary()
    print(f"Statistics: {summary}")
