"""
Machine Learning Model Module
Implements Isolation Forest for network anomaly detection
"""

import numpy as np
import pickle
from pathlib import Path
from sklearn.ensemble import IsolationForest
from sklearn.metrics import classification_report, confusion_matrix
from typing import List, Dict, Tuple, Optional
import config
from logger import logger

class AnomalyDetector:
    """
    Machine learning-based anomaly detector using Isolation Forest
    """
    
    def __init__(self, model_path=None):
        """
        Initialize anomaly detector
        
        Args:
            model_path: Path to saved model file
        """
        self.model = None
        self.model_path = model_path or (config.MODEL_DIR / "isolation_forest.pkl")
        self.is_trained = False
        
        # Model parameters from config
        self.contamination = config.ML_CONFIG['contamination']
        self.n_estimators = config.ML_CONFIG['n_estimators']
        self.max_samples = config.ML_CONFIG['max_samples']
        self.random_state = config.ML_CONFIG['random_state']
        self.anomaly_threshold = config.ML_CONFIG['anomaly_threshold']
        
        # Training statistics
        self.training_samples = 0
        self.last_training_time = None
        
        # Load existing model if available
        if self.model_path.exists():
            self.load_model()
        else:
            self._initialize_model()
        
        logger.log_system_event("AnomalyDetector initialized", 
                               f"Model: {self.model_path}")
    
    def _initialize_model(self):
        """Initialize a new Isolation Forest model"""
        self.model = IsolationForest(
            contamination=self.contamination,
            n_estimators=self.n_estimators,
            max_samples=self.max_samples,
            random_state=self.random_state,
            n_jobs=-1,  # Use all CPU cores
            verbose=0
        )
        logger.info("Initialized new Isolation Forest model")
    
    def train(self, features: np.ndarray, labels: Optional[np.ndarray] = None):
        """
        Train the anomaly detection model
        
        Args:
            features: Feature matrix (n_samples, n_features)
            labels: Optional ground truth labels (for evaluation only)
        """
        if features.size == 0:
            logger.warning("No features provided for training")
            return
        
        if len(features.shape) == 1:
            features = features.reshape(1, -1)
        
        n_samples = features.shape[0]
        min_samples = config.ML_CONFIG['min_training_samples']
        
        if n_samples < min_samples:
            logger.warning(f"Insufficient training samples: {n_samples} < {min_samples}")
            return
        
        logger.info(f"Training Isolation Forest on {n_samples} samples...")
        
        # Train model
        self.model.fit(features)
        self.is_trained = True
        self.training_samples = n_samples
        
        import time
        self.last_training_time = time.time()
        
        # Evaluate if labels provided
        if labels is not None:
            self.evaluate(features, labels)
        
        # Save model
        self.save_model()
        
        logger.log_model_trained(n_samples)
    
    def predict(self, features: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Predict anomalies in feature data
        
        Args:
            features: Feature matrix or vector
            
        Returns:
            Tuple of (predictions, anomaly_scores)
            predictions: 1 for normal, -1 for anomaly
            anomaly_scores: Lower scores indicate anomalies
        """
        if not self.is_trained:
            logger.warning("Model not trained, returning default predictions")
            if features.ndim == 1:
                return np.array([1]), np.array([0.0])
            return np.ones(features.shape[0]), np.zeros(features.shape[0])
        
        # Reshape if single sample
        if features.ndim == 1:
            features = features.reshape(1, -1)
        
        # Get predictions and scores
        predictions = self.model.predict(features)
        anomaly_scores = self.model.score_samples(features)
        
        return predictions, anomaly_scores
    
    def is_anomaly(self, features: np.ndarray) -> Tuple[bool, float]:
        """
        Check if a single sample is an anomaly
        
        Args:
            features: Feature vector
            
        Returns:
            Tuple of (is_anomaly, anomaly_score)
        """
        predictions, scores = self.predict(features)
        is_anomalous = predictions[0] == -1
        score = scores[0]
        
        # Also check against threshold
        threshold_check = score < self.anomaly_threshold
        
        return is_anomalous or threshold_check, score
    
    def predict_proba(self, features: np.ndarray) -> np.ndarray:
        """
        Get anomaly probability (based on decision function)
        
        Args:
            features: Feature matrix or vector
            
        Returns:
            Anomaly probabilities (0-1)
        """
        if not self.is_trained:
            return np.zeros(1) if features.ndim == 1 else np.zeros(features.shape[0])
        
        if features.ndim == 1:
            features = features.reshape(1, -1)
        
        # Convert anomaly scores to probabilities
        scores = self.model.decision_function(features)
        # Normalize to 0-1 range (higher = more anomalous)
        proba = 1 / (1 + np.exp(scores))
        
        return proba
    
    def evaluate(self, features: np.ndarray, labels: np.ndarray) -> Dict:
        """
        Evaluate model performance
        
        Args:
            features: Feature matrix
            labels: Ground truth labels (1=normal, -1=anomaly)
            
        Returns:
            Evaluation metrics dictionary
        """
        if not self.is_trained:
            logger.warning("Model not trained, cannot evaluate")
            return {}
        
        predictions, scores = self.predict(features)
        
        # Calculate metrics
        cm = confusion_matrix(labels, predictions)
        
        # True/False Positives/Negatives
        tn = cm[0, 0] if cm.shape[0] > 1 else 0
        fp = cm[0, 1] if cm.shape[0] > 1 and cm.shape[1] > 1 else 0
        fn = cm[1, 0] if cm.shape[0] > 1 else 0
        tp = cm[1, 1] if cm.shape[0] > 1 and cm.shape[1] > 1 else 0
        
        accuracy = (tp + tn) / (tp + tn + fp + fn) if (tp + tn + fp + fn) > 0 else 0
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        
        metrics = {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'true_positives': int(tp),
            'false_positives': int(fp),
            'true_negatives': int(tn),
            'false_negatives': int(fn),
        }
        
        logger.info(f"Model Evaluation:")
        logger.info(f"  Accuracy: {accuracy:.3f}")
        logger.info(f"  Precision: {precision:.3f}")
        logger.info(f"  Recall: {recall:.3f}")
        logger.info(f"  F1-Score: {f1:.3f}")
        
        return metrics
    
    def save_model(self, path: Optional[Path] = None):
        """
        Save trained model to disk
        
        Args:
            path: Optional custom path
        """
        if not self.is_trained:
            logger.warning("Model not trained, nothing to save")
            return
        
        save_path = path or self.model_path
        
        try:
            with open(save_path, 'wb') as f:
                pickle.dump({
                    'model': self.model,
                    'is_trained': self.is_trained,
                    'training_samples': self.training_samples,
                    'contamination': self.contamination,
                    'threshold': self.anomaly_threshold,
                }, f)
            
            logger.info(f"Model saved to {save_path}")
        except Exception as e:
            logger.error(f"Failed to save model: {str(e)}")
    
    def load_model(self, path: Optional[Path] = None):
        """
        Load trained model from disk
        
        Args:
            path: Optional custom path
        """
        load_path = path or self.model_path
        
        if not load_path.exists():
            logger.warning(f"Model file not found: {load_path}")
            return False
        
        try:
            with open(load_path, 'rb') as f:
                data = pickle.load(f)
            
            self.model = data['model']
            self.is_trained = data['is_trained']
            self.training_samples = data.get('training_samples', 0)
            self.contamination = data.get('contamination', self.contamination)
            self.anomaly_threshold = data.get('threshold', self.anomaly_threshold)
            
            logger.info(f"Model loaded from {load_path}")
            logger.info(f"  Training samples: {self.training_samples}")
            return True
        except Exception as e:
            logger.error(f"Failed to load model: {str(e)}")
            return False
    
    def retrain_if_needed(self, features: np.ndarray, force: bool = False) -> bool:
        """
        Retrain model if conditions are met
        
        Args:
            features: New training features
            force: Force retraining regardless of conditions
            
        Returns:
            True if retrained
        """
        import time
        
        should_retrain = force
        
        # Check if enough time has passed since last training
        if self.last_training_time:
            time_since_training = time.time() - self.last_training_time
            retrain_interval = config.ML_CONFIG['retrain_interval']
            
            if time_since_training > retrain_interval:
                should_retrain = True
                logger.info(f"Retraining due to time interval ({time_since_training:.0f}s)")
        
        # Check if we have significantly more data
        if features.shape[0] > self.training_samples * 1.5:
            should_retrain = True
            logger.info(f"Retraining due to increased data volume")
        
        if should_retrain:
            self.train(features)
            return True
        
        return False
    
    def get_statistics(self) -> Dict:
        """
        Get model statistics
        
        Returns:
            Statistics dictionary
        """
        return {
            'is_trained': self.is_trained,
            'training_samples': self.training_samples,
            'contamination': self.contamination,
            'n_estimators': self.n_estimators,
            'anomaly_threshold': self.anomaly_threshold,
            'model_path': str(self.model_path),
        }

if __name__ == "__main__":
    # Test anomaly detector
    print("Anomaly Detector Test")
    print("=" * 50)
    
    detector = AnomalyDetector()
    
    # Generate synthetic training data
    np.random.seed(42)
    
    # Normal traffic (cluster around mean)
    normal_features = np.random.randn(100, 15) * 2 + 10
    
    # Anomalous traffic (outliers)
    anomaly_features = np.random.randn(10, 15) * 10 + 50
    
    # Combine
    all_features = np.vstack([normal_features, anomaly_features])
    labels = np.array([1] * 100 + [-1] * 10)  # 1=normal, -1=anomaly
    
    # Train
    print("\nTraining model...")
    detector.train(normal_features)
    
    # Predict
    print("\nTesting predictions...")
    predictions, scores = detector.predict(all_features)
    
    detected_anomalies = np.sum(predictions == -1)
    print(f"Detected {detected_anomalies} anomalies out of {len(all_features)} samples")
    
    # Evaluate
    print("\nEvaluating model...")
    metrics = detector.evaluate(all_features, labels)
    
    # Test single sample
    test_sample = anomaly_features[0]
    is_anom, score = detector.is_anomaly(test_sample)
    print(f"\nSingle sample test: Anomaly={is_anom}, Score={score:.3f}")
    
    # Statistics
    stats = detector.get_statistics()
    print(f"\nModel statistics: {stats}")
