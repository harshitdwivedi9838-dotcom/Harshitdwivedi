"""
Rule-based Attack Detection Module
Implements heuristic detectors for common network attacks
"""

import time
from collections import defaultdict, deque
from typing import Dict, List, Optional, Tuple
import config
from logger import logger

class AttackDetector:
    """
    Rule-based detection for common network attacks
    """
    
    def __init__(self):
        """Initialize attack detector"""
        self.rules_config = config.RULES_CONFIG
        
        # Port scan detection state
        self.port_scan_tracker = defaultdict(lambda: {
            'ports': set(),
            'timestamps': deque(),
            'packet_count': 0
        })
        
        # SYN flood detection state
        self.syn_tracker = defaultdict(lambda: {
            'syn_count': deque(),
            'last_check': time.time()
        })
        
        # Traffic spike detection state
        self.traffic_baseline = defaultdict(lambda: {
            'packets': deque(),
            'bytes': deque(),
            'timestamps': deque()
        })
        
        # Attack history
        self.detected_attacks = []
        
        logger.log_system_event("AttackDetector initialized")
    
    def analyze_flow(self, flow: Dict) -> List[Dict]:
        """
        Analyze flow for potential attacks
        
        Args:
            flow: Flow dictionary
            
        Returns:
            List of detected attacks (empty if none)
        """
        attacks = []
        
        # Run all enabled detection rules
        if self.rules_config['port_scan']['enabled']:
            port_scan = self._detect_port_scan(flow)
            if port_scan:
                attacks.append(port_scan)
        
        if self.rules_config['syn_flood']['enabled'] and flow['protocol'] == 6:
            syn_flood = self._detect_syn_flood(flow)
            if syn_flood:
                attacks.append(syn_flood)
        
        if self.rules_config['traffic_spike']['enabled']:
            spike = self._detect_traffic_spike(flow)
            if spike:
                attacks.append(spike)
        
        if self.rules_config['unusual_protocol']['enabled']:
            unusual = self._detect_unusual_protocol(flow)
            if unusual:
                attacks.append(unusual)
        
        # Log and store attacks
        for attack in attacks:
            self.detected_attacks.append(attack)
            logger.log_attack_detected(
                attack['type'],
                attack['source_ip'],
                attack['details']
            )
        
        return attacks
    
    def _detect_port_scan(self, flow: Dict) -> Optional[Dict]:
        """
        Detect port scanning activity
        
        A port scan is detected when a source IP connects to many different
        destination ports on the same or different hosts within a time window.
        
        Args:
            flow: Flow dictionary
            
        Returns:
            Attack dictionary if detected, None otherwise
        """
        src_ip = flow['src_ip']
        dst_port = flow.get('dst_port')
        
        if dst_port is None:
            return None
        
        config_ps = self.rules_config['port_scan']
        time_window = config_ps['time_window']
        threshold = config_ps['unique_ports_threshold']
        min_packets = config_ps['min_packets']
        
        tracker = self.port_scan_tracker[src_ip]
        current_time = time.time()
        
        # Add port and timestamp
        tracker['ports'].add(dst_port)
        tracker['timestamps'].append(current_time)
        tracker['packet_count'] += flow.get('packet_count', 1)
        
        # Remove old timestamps outside time window
        while tracker['timestamps'] and current_time - tracker['timestamps'][0] > time_window:
            tracker['timestamps'].popleft()
        
        # Check if threshold exceeded
        unique_ports = len(tracker['ports'])
        if unique_ports >= threshold and tracker['packet_count'] >= min_packets:
            attack = {
                'type': 'Port Scan',
                'source_ip': src_ip,
                'target_ip': flow.get('dst_ip'),
                'severity': 'MEDIUM',
                'details': f"{unique_ports} unique ports scanned in {time_window}s",
                'packet_count': tracker['packet_count'],
                'unique_ports': unique_ports,
                'timestamp': current_time
            }
            
            # Reset tracker after detection
            tracker['ports'].clear()
            tracker['timestamps'].clear()
            tracker['packet_count'] = 0
            
            return attack
        
        return None
    
    def _detect_syn_flood(self, flow: Dict) -> Optional[Dict]:
        """
        Detect SYN flood attack
        
        SYN flood is detected when excessive SYN packets are sent from a source
        without corresponding ACK packets (incomplete TCP handshakes).
        
        Args:
            flow: Flow dictionary
            
        Returns:
            Attack dictionary if detected, None otherwise
        """
        src_ip = flow['src_ip']
        syn_count = flow.get('syn_count', 0)
        
        if syn_count == 0:
            return None
        
        config_sf = self.rules_config['syn_flood']
        time_window = config_sf['time_window']
        threshold = config_sf['syn_threshold']
        
        tracker = self.syn_tracker[src_ip]
        current_time = time.time()
        
        # Add SYN count with timestamp
        tracker['syn_count'].append((current_time, syn_count))
        
        # Remove old entries outside time window
        while tracker['syn_count'] and current_time - tracker['syn_count'][0][0] > time_window:
            tracker['syn_count'].popleft()
        
        # Calculate total SYN packets in window
        total_syn = sum(count for _, count in tracker['syn_count'])
        syn_rate = total_syn / time_window
        
        # Check if threshold exceeded
        if syn_rate >= threshold:
            attack = {
                'type': 'SYN Flood',
                'source_ip': src_ip,
                'target_ip': flow.get('dst_ip'),
                'severity': 'HIGH',
                'details': f"{total_syn} SYN packets in {time_window}s ({syn_rate:.1f} SYN/s)",
                'packet_count': total_syn,
                'syn_rate': syn_rate,
                'timestamp': current_time
            }
            
            # Reset tracker
            tracker['syn_count'].clear()
            
            return attack
        
        return None
    
    def _detect_traffic_spike(self, flow: Dict) -> Optional[Dict]:
        """
        Detect unusual traffic spikes
        
        A spike is detected when traffic rate exceeds normal baseline by
        a significant multiplier.
        
        Args:
            flow: Flow dictionary
            
        Returns:
            Attack dictionary if detected, None otherwise
        """
        src_ip = flow['src_ip']
        packet_count = flow.get('packet_count', 0)
        byte_count = flow.get('byte_count', 0)
        
        config_ts = self.rules_config['traffic_spike']
        baseline_window = config_ts['baseline_window']
        spike_multiplier = config_ts['spike_multiplier']
        
        tracker = self.traffic_baseline[src_ip]
        current_time = time.time()
        
        # Add current traffic
        tracker['packets'].append(packet_count)
        tracker['bytes'].append(byte_count)
        tracker['timestamps'].append(current_time)
        
        # Remove old entries
        while tracker['timestamps'] and current_time - tracker['timestamps'][0] > baseline_window:
            tracker['timestamps'].popleft()
            tracker['packets'].popleft()
            tracker['bytes'].popleft()
        
        # Need enough history for baseline
        if len(tracker['packets']) < 10:
            return None
        
        # Calculate baseline (average of recent traffic)
        baseline_packets = sum(list(tracker['packets'])[:-1]) / (len(tracker['packets']) - 1)
        baseline_bytes = sum(list(tracker['bytes'])[:-1]) / (len(tracker['bytes']) - 1)
        
        # Check for spike
        if packet_count > baseline_packets * spike_multiplier:
            attack = {
                'type': 'Traffic Spike',
                'source_ip': src_ip,
                'target_ip': flow.get('dst_ip'),
                'severity': 'MEDIUM',
                'details': f"Packet rate {spike_multiplier:.1f}x above baseline "
                          f"({packet_count} vs {baseline_packets:.1f} avg)",
                'packet_count': packet_count,
                'baseline': baseline_packets,
                'multiplier': packet_count / baseline_packets if baseline_packets > 0 else 0,
                'timestamp': current_time
            }
            return attack
        
        return None
    
    def _detect_unusual_protocol(self, flow: Dict) -> Optional[Dict]:
        """
        Detect unusual or uncommon protocols
        
        Args:
            flow: Flow dictionary
            
        Returns:
            Attack dictionary if detected, None otherwise
        """
        protocol = flow.get('protocol')
        common_protocols = self.rules_config['unusual_protocol']['common_protocols']
        
        if protocol not in common_protocols:
            attack = {
                'type': 'Unusual Protocol',
                'source_ip': flow['src_ip'],
                'target_ip': flow.get('dst_ip'),
                'severity': 'LOW',
                'details': f"Uncommon protocol detected: {protocol}",
                'protocol': protocol,
                'timestamp': time.time()
            }
            return attack
        
        return None
    
    def get_attack_summary(self, minutes: int = 60) -> Dict:
        """
        Get summary of attacks in last N minutes
        
        Args:
            minutes: Time window in minutes
            
        Returns:
            Attack summary dictionary
        """
        current_time = time.time()
        cutoff_time = current_time - (minutes * 60)
        
        recent_attacks = [a for a in self.detected_attacks 
                         if a['timestamp'] > cutoff_time]
        
        # Count by type
        attack_counts = defaultdict(int)
        for attack in recent_attacks:
            attack_counts[attack['type']] += 1
        
        # Count by severity
        severity_counts = defaultdict(int)
        for attack in recent_attacks:
            severity_counts[attack['severity']] += 1
        
        # Top attacking IPs
        ip_counts = defaultdict(int)
        for attack in recent_attacks:
            ip_counts[attack['source_ip']] += 1
        
        top_attackers = sorted(ip_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        
        return {
            'total_attacks': len(recent_attacks),
            'time_window_minutes': minutes,
            'attacks_by_type': dict(attack_counts),
            'attacks_by_severity': dict(severity_counts),
            'top_attacking_ips': top_attackers,
            'recent_attacks': recent_attacks[-10:]  # Last 10 attacks
        }
    
    def clear_old_attacks(self, hours: int = 24):
        """
        Clear attack history older than specified hours
        
        Args:
            hours: Age threshold in hours
        """
        current_time = time.time()
        cutoff_time = current_time - (hours * 3600)
        
        self.detected_attacks = [a for a in self.detected_attacks 
                                if a['timestamp'] > cutoff_time]
        
        logger.info(f"Cleared attacks older than {hours} hours")
    
    def get_statistics(self) -> Dict:
        """
        Get attack detector statistics
        
        Returns:
            Statistics dictionary
        """
        return {
            'total_attacks_detected': len(self.detected_attacks),
            'active_port_scan_trackers': len(self.port_scan_tracker),
            'active_syn_trackers': len(self.syn_tracker),
            'enabled_rules': [name for name, cfg in self.rules_config.items() 
                            if isinstance(cfg, dict) and cfg.get('enabled', False)],
        }

if __name__ == "__main__":
    # Test attack detector
    print("Attack Detector Test")
    print("=" * 50)
    
    detector = AttackDetector()
    
    # Test port scan detection
    print("\n1. Testing Port Scan Detection...")
    for port in range(80, 105):  # Scan 25 ports
        flow = {
            'src_ip': '192.168.1.100',
            'dst_ip': '10.0.0.1',
            'dst_port': port,
            'protocol': 6,
            'packet_count': 2,
        }
        attacks = detector.analyze_flow(flow)
        if attacks:
            print(f"  DETECTED: {attacks[0]}")
    
    # Test SYN flood
    print("\n2. Testing SYN Flood Detection...")
    for i in range(150):
        flow = {
            'src_ip': '192.168.1.200',
            'dst_ip': '10.0.0.2',
            'dst_port': 80,
            'protocol': 6,
            'packet_count': 1,
            'syn_count': 1,
        }
        attacks = detector.analyze_flow(flow)
        if attacks:
            print(f"  DETECTED: {attacks[0]}")
            break
    
    # Get summary
    print("\n3. Attack Summary:")
    summary = detector.get_attack_summary()
    print(f"  Total attacks: {summary['total_attacks']}")
    print(f"  By type: {summary['attacks_by_type']}")
    print(f"  By severity: {summary['attacks_by_severity']}")
    
    # Statistics
    stats = detector.get_statistics()
    print(f"\n4. Statistics: {stats}")
